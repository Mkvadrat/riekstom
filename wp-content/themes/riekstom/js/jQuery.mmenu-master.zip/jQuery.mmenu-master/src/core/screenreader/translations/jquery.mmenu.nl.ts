(function( $ ) {

	var _PLUGIN_ = 'mmenu';

	$[ _PLUGIN_ ].i18n({
		'Close menu'		: 'Menu sluiten',
		'Close submenu'		: 'Submenu sluiten',
		'Open submenu' 		: 'Submenu openen',
		'Toggle submenu' 	: 'Submenu wisselen'
	});

})( jQuery );