(function( $ ) {

	var _PLUGIN_ = 'mmenu';

	$[ _PLUGIN_ ].i18n({
		'Close menu'		: 'Menü schließen',
		'Close submenu'		: 'Untermenü schließen',
		'Open submenu' 		: 'Untermenü öffnen',
		'Toggle submenu' 	: 'Untermenü wechseln'
	});

})( jQuery );